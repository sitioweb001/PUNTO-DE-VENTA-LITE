#!/usr/bin/env python3
# ═══════════════════════════════════════════════════════════════════════
# ERP POS LITE — API LOCAL (Python + SQLite)
# Reemplaza a api.php + MySQL/XAMPP para el modo "localhost".
#
# Usa SOLO la librería estándar de Python (http.server, sqlite3, json,
# urllib) — no hace falta "pip install" nada para correrlo.
#
# Contrato con el frontend: el mismo que ya usaba api.php/Code.gs —
# GET  /api?action=NOMBRE&param=valor...
# POST /api   body JSON: {"action": "NOMBRE", ...}
# Respuesta siempre JSON: {"status": "success"|"error"|..., ...}
#
# Arquitectura de sincronización:
#   - Toda escritura local (ventas, productos, categorías, etc.) se guarda
#     PRIMERO en SQLite (nunca depende de que Apps Script responda) y
#     además se encola en la tabla sync_queue.
#   - Un hilo en segundo plano (y también la acción "sincronizar", que el
#     frontend puede llamar cuando quiera) procesa esa cola: manda cada
#     pendiente a Apps Script, y si responde bien lo marca SINCRONIZADO.
#     Si falla (sin internet, Apps Script lento/caído), se queda
#     PENDIENTE y se reintenta solo, sin perder nada.
#   - Además se descargan cambios NUEVOS desde Apps Script/Sheets hacia
#     SQLite (por ejemplo, ventas hechas desde el sitio de GitHub), sin
#     duplicar lo que ya existe localmente (se compara por id).
#   - Todas las acciones de "crear" son IDEMPOTENTES: si llega un id que
#     ya existe, no se vuelve a insertar ni se repite el efecto (stock,
#     etc.) — así un reintento nunca duplica ni descuenta dos veces.
# ═══════════════════════════════════════════════════════════════════════

import json
import os
import re
import shutil
import sqlite3
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

# ═══════════════════════════════════════════════════════════════
# CONFIGURACIÓN — edita esto si hace falta
# ═══════════════════════════════════════════════════════════════
PUERTO = 8000

# Pega aquí la MISMA URL de Apps Script que ya usa tu sistema (la que
# tenías en APPSCRIPT_URL_ORIGINAL dentro de index.html).
APPSCRIPT_URL = "https://script.google.com/macros/s/AKfycbwbYNUf0--D2RVqFyaBZHFxQuClX6RBybuhK6kJU9Q02NZyICUIXEnUWIR1x25xMnfMrA/exec"

# Cada cuántos segundos se procesa la cola de sincronización sola, en
# segundo plano, sin que el usuario tenga que hacer nada.
INTERVALO_SYNC_SEGUNDOS = 45

# Zona horaria del negocio (para que todas las fechas salgan consistentes,
# sin el problema de desfase de horas que tuvimos con MySQL/Sheets).
ZONA_HORARIA_OFFSET = "-06:00"  # El Salvador

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "erp_pos_lite.db"
# Detecta solo si index.html está en la MISMA carpeta que este server.py
# (todo junto, como lo tienes tú) o un nivel arriba (carpeta backend/
# separada). Así funciona con cualquiera de las dos formas de organizar
# los archivos, sin que tengas que mover nada.
FRONTEND_DIR = BASE_DIR if (BASE_DIR / "index.html").exists() else BASE_DIR.parent

# ═══════════════════════════════════════════════════════════════
# BASE DE DATOS
# ═══════════════════════════════════════════════════════════════
_local = threading.local()
# Candado global: solo un hilo de Python toca SQLite a la vez, sin
# importar cuántas conexiones distintas existan. Esto evita depender del
# bloqueo de archivos del sistema operativo entre conexiones separadas
# (que en Windows se comporta distinto y más delicado que en Linux/Mac,
# y era la causa de fondo de "database is locked" incluso en operaciones
# tan simples como fijar un PRAGMA en una conexión nueva).
DB_LOCK = threading.RLock()

# CAMBIO IMPORTANTE: antes cada hilo (cada pedido HTTP) abría su PROPIA
# conexión a SQLite — o sea, existían varias conexiones distintas al
# mismo archivo al mismo tiempo. Aunque DB_LOCK coordinaba CUÁNDO cada
# una podía escribir, seguía dependiendo de que SQLite/Windows coordinaran
# bien esas conexiones separadas entre sí. Ahora hay UNA SOLA conexión
# para todo el programa (compartida entre todos los hilos), así que ya
# no existe "coordinación entre conexiones" de la que depender — solo
# queda el candado de Python, que es 100% confiable dentro de un mismo proceso.
_conn_compartida = None
_journal_mode_listo = False


def db():
    """Conexión ÚNICA compartida por todo el programa. SIEMPRE se usa
    dentro de un "with DB_LOCK:" — nunca sola — porque una misma conexión
    SQLite no es segura para que dos hilos la usen al mismo tiempo sin coordinarse."""
    global _conn_compartida
    if _conn_compartida is None:
        conn = sqlite3.connect(str(DB_PATH), timeout=15, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=15000")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA foreign_keys=ON")
        _conn_compartida = conn
    return _conn_compartida



def fijar_journal_mode_una_vez():
    """Cambia el modo de journal UNA sola vez, al arrancar el servidor,
    antes de que exista ningún otro hilo compitiendo por la base. Modo
    clásico (DELETE) en vez de WAL: WAL necesita un archivo de memoria
    compartida (.db-shm) con un tipo de bloqueo que en Windows puede
    fallar (antivirus, "Acceso controlado a carpetas", ciertas
    configuraciones de disco) — el síntoma es "database is locked" en
    todos los intentos de escritura, sin importar cuántos reintentos."""
    global _journal_mode_listo
    if _journal_mode_listo:
        return
    conn = sqlite3.connect(str(DB_PATH), timeout=15)
    conn.execute("PRAGMA wal_checkpoint(FULL)")  # por si hay un WAL viejo, se aplica al .db principal antes de cambiar de modo
    conn.execute("PRAGMA journal_mode=DELETE")
    conn.close()
    # Restos de una instalación anterior en modo WAL (-wal/-shm) que el
    # checkpoint de arriba no haya podido limpiar del todo (por ejemplo,
    # si quedaron de una versión vieja de este mismo programa, antes de
    # cambiar a modo clásico). Si sobran, se borran explícitamente — para
    # esto ya no hace falta ningún dato de ahí, todo lo real vive en el
    # archivo .db principal.
    for sufijo in ("-wal", "-shm"):
        residual = Path(str(DB_PATH) + sufijo)
        if residual.exists():
            try:
                residual.unlink()
                print(f"[erp-pos-lite] Se limpió un archivo viejo de WAL: {residual.name}")
            except Exception as e:
                print(f"[erp-pos-lite] No se pudo limpiar {residual.name} (no es grave): {e}")
    _journal_mode_listo = True


ESQUEMA = """
CREATE TABLE IF NOT EXISTS categorias (
  id TEXT PRIMARY KEY,
  nombre TEXT NOT NULL,
  emoji TEXT DEFAULT '📦',
  activo INTEGER DEFAULT 1,
  created_at TEXT, updated_at TEXT, deleted_at TEXT
);

CREATE TABLE IF NOT EXISTS productos (
  id TEXT PRIMARY KEY,
  nombre TEXT NOT NULL,
  codigo TEXT DEFAULT '',
  categoria TEXT DEFAULT '',
  precio_compra REAL DEFAULT 0,
  precio_venta REAL DEFAULT 0,
  stock INTEGER DEFAULT 0,
  stock_minimo INTEGER DEFAULT 5,
  imagen_url TEXT DEFAULT '',
  favorito INTEGER DEFAULT 0,
  activo INTEGER DEFAULT 1,
  fecha_creado TEXT,
  proveedor_nombre TEXT DEFAULT '',
  proveedor_whatsapp TEXT DEFAULT '',
  proveedor_correo TEXT DEFAULT '',
  proveedor_fecha_entrada TEXT,
  updated_at TEXT, deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_productos_codigo ON productos(codigo);
CREATE INDEX IF NOT EXISTS idx_productos_activo ON productos(activo);

CREATE TABLE IF NOT EXISTS compras (
  id TEXT PRIMARY KEY,
  producto_id TEXT NOT NULL,
  cantidad INTEGER DEFAULT 0,
  precio_compra REAL DEFAULT 0,
  fecha TEXT,
  usuario TEXT DEFAULT 'Sistema',
  notas TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_compras_producto ON compras(producto_id);
CREATE INDEX IF NOT EXISTS idx_compras_fecha ON compras(fecha);

CREATE TABLE IF NOT EXISTS ventas (
  id TEXT PRIMARY KEY,
  fecha TEXT,
  cliente_nombre TEXT DEFAULT 'N/A',
  cliente_whatsapp TEXT DEFAULT 'N/A',
  cliente_correo TEXT DEFAULT 'N/A',
  subtotal REAL DEFAULT 0,
  descuento REAL DEFAULT 0,
  impuesto REAL DEFAULT 0,
  total REAL DEFAULT 0,
  pago_con REAL DEFAULT 0,
  cambio REAL DEFAULT 0,
  usuario TEXT DEFAULT 'Sistema',
  estado TEXT DEFAULT 'completada'
);
CREATE INDEX IF NOT EXISTS idx_ventas_fecha ON ventas(fecha);

CREATE TABLE IF NOT EXISTS venta_detalle (
  id TEXT PRIMARY KEY,
  venta_id TEXT NOT NULL,
  producto_id TEXT,
  producto_nombre TEXT DEFAULT '',
  cantidad INTEGER DEFAULT 0,
  precio_unitario REAL DEFAULT 0,
  descuento_linea REAL DEFAULT 0,
  subtotal_linea REAL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_detalle_venta ON venta_detalle(venta_id);

CREATE TABLE IF NOT EXISTS papelera (
  id TEXT PRIMARY KEY,
  tipo TEXT DEFAULT 'Producto',
  datos_originales TEXT,
  fecha_eliminado TEXT,
  eliminado_por TEXT DEFAULT 'Sistema'
);

CREATE TABLE IF NOT EXISTS actividad (
  id TEXT PRIMARY KEY,
  fecha TEXT,
  usuario TEXT DEFAULT 'Sistema',
  accion TEXT DEFAULT '',
  detalle TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS soporte (
  id TEXT PRIMARY KEY,
  usuario TEXT DEFAULT '',
  titulo TEXT DEFAULT '',
  descripcion TEXT DEFAULT '',
  estado TEXT DEFAULT 'nuevo',
  fecha TEXT,
  fecha_actualizado TEXT,
  respuesta TEXT DEFAULT '',
  admin TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS responsables (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL,
  nombre TEXT DEFAULT '',
  reportes TEXT DEFAULT '',
  umbral_venta_grande REAL DEFAULT 100,
  activo INTEGER DEFAULT 1,
  ultimo_envio_mensual TEXT DEFAULT '',
  ultimo_envio_anual TEXT DEFAULT '',
  ultimo_envio_stock TEXT DEFAULT '',
  fecha_creado TEXT,
  ultimo_envio_backup TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS config (
  clave TEXT PRIMARY KEY,
  valor TEXT DEFAULT ''
);

-- Cola de sincronización: cada fila es UNA operación de escritura
-- pendiente de mandar a Apps Script/Google Sheets. Nunca se borra por un
-- fallo (sin internet, timeout, Apps Script caído) — se reintenta sola.
CREATE TABLE IF NOT EXISTS sync_queue (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tabla TEXT,
  registro_id TEXT,
  operacion TEXT,
  payload TEXT,
  estado TEXT DEFAULT 'PENDIENTE',   -- PENDIENTE | SINCRONIZANDO | SINCRONIZADO | ERROR
  intentos INTEGER DEFAULT 0,
  ultimo_intento TEXT,
  fecha_creacion TEXT,
  fecha_ultimo_error TEXT,
  error TEXT,
  fecha_sincronizacion TEXT
);
CREATE INDEX IF NOT EXISTS idx_sync_estado ON sync_queue(estado);
"""


def inicializar_bd():
    primera_vez = not DB_PATH.exists()
    fijar_journal_mode_una_vez()
    conn = db()
    conn.executescript(ESQUEMA)
    conn.commit()
    if primera_vez:
        print(f"[erp-pos-lite] Base de datos nueva creada en: {DB_PATH}")
    else:
        print(f"[erp-pos-lite] Base de datos existente cargada: {DB_PATH}")


# ═══════════════════════════════════════════════════════════════
# UTILIDADES
# ═══════════════════════════════════════════════════════════════
def ahora_iso():
    """Fecha/hora actual con el offset de zona horaria pegado explícito
    (mismo criterio que ya corregimos en api.php): evita que el navegador
    tenga que adivinar en qué zona horaria está la fecha."""
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S") + ZONA_HORARIA_OFFSET


def uid():
    # Mismo formato que usa Code.gs / api.php, para que los ids sean
    # compatibles y no se note la diferencia entre backends.
    import base64
    import secrets
    ts = format(int(time.time() * 1000), "x")
    rand = secrets.token_hex(4)
    return ("id-" + ts + rand).upper()


def get_config(clave, default=""):
    row = db().execute("SELECT valor FROM config WHERE clave=?", (clave,)).fetchone()
    return row["valor"] if row else default


def set_config(clave, valor):
    db().execute(
        "INSERT INTO config (clave, valor) VALUES (?, ?) "
        "ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor",
        (clave, valor),
    )
    db().commit()


def log_actividad(usuario, accion, detalle):
    try:
        db().execute(
            "INSERT INTO actividad (id, fecha, usuario, accion, detalle) VALUES (?,?,?,?,?)",
            (uid(), ahora_iso(), usuario or "Sistema", accion, detalle or ""),
        )
        db().commit()
    except Exception:
        pass


def normalizar_codigo(codigo):
    codigo = (codigo or "").strip()
    return re.sub(r"^0+(?=.)", "", codigo).lower()


def existe_id(tabla, id_):
    if not id_:
        return False
    row = db().execute(f"SELECT 1 FROM {tabla} WHERE id=?", (id_,)).fetchone()
    return row is not None


def row_to_dict(row):
    return {k: row[k] for k in row.keys()} if row else None


def rows_to_list(rows):
    return [row_to_dict(r) for r in rows]


# ── Cola de sincronización ──
def encolar(tabla, registro_id, operacion, payload_dict):
    """Guarda una operación pendiente de mandar a Apps Script. Se llama
    DESPUÉS de que la escritura ya se aplicó en SQLite — la venta (o lo
    que sea) ya está guardada y segura ANTES de intentar sincronizar nada."""
    try:
        db().execute(
            "INSERT INTO sync_queue (tabla, registro_id, operacion, payload, estado, intentos, fecha_creacion) "
            "VALUES (?,?,?,?, 'PENDIENTE', 0, ?)",
            (tabla, registro_id, operacion, json.dumps(payload_dict, ensure_ascii=False), ahora_iso()),
        )
        db().commit()
    except Exception as e:
        print("[sync] no se pudo encolar:", e)


def llamar_appscript(payload_dict, timeout=60):
    """POST a Apps Script. Devuelve (ok, respuesta_dict_o_None, error_texto)."""
    try:
        body = json.dumps(payload_dict, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(APPSCRIPT_URL, data=body, method="POST",
                                      headers={"Content-Type": "text/plain;charset=UTF-8"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            out = resp.read().decode("utf-8")
        data = json.loads(out)
        if isinstance(data, dict) and data.get("status") == "success":
            return True, data, None
        return False, data, (data.get("message") if isinstance(data, dict) else "Respuesta inesperada")
    except Exception as e:
        return False, None, str(e)


def procesar_cola_sincronizacion(max_items=50):
    """Recorre la cola PENDIENTE y manda cada una a Apps Script. No bloquea
    la app: se llama desde el hilo de fondo y también bajo pedido. El
    candado (DB_LOCK) solo se toma para leer/escribir SQLite — nunca
    mientras se espera la respuesta de Apps Script (llamar_appscript),
    para no bloquear el resto del sistema durante esos segundos."""
    with DB_LOCK:
        pendientes = db().execute(
            "SELECT * FROM sync_queue WHERE estado IN ('PENDIENTE','ERROR') ORDER BY id ASC LIMIT ?",
            (max_items,),
        ).fetchall()
    ok_count, fallo_count = 0, 0
    for item in pendientes:
        payload = json.loads(item["payload"])
        ok, resp_data, error = llamar_appscript(payload)  # sin el candado — puede tardar segundos
        ahora = ahora_iso()
        with DB_LOCK:
            if ok:
                db().execute(
                    "UPDATE sync_queue SET estado='SINCRONIZADO', fecha_sincronizacion=?, ultimo_intento=? WHERE id=?",
                    (ahora, ahora, item["id"]),
                )
                ok_count += 1
            else:
                db().execute(
                    "UPDATE sync_queue SET estado='ERROR', intentos=intentos+1, ultimo_intento=?, "
                    "fecha_ultimo_error=?, error=? WHERE id=?",
                    (ahora, ahora, str(error)[:500], item["id"]),
                )
                fallo_count += 1
            db().commit()
    return {"ok": ok_count, "fallo": fallo_count, "revisados": len(pendientes)}


def hilo_sincronizacion_fondo():
    while True:
        time.sleep(INTERVALO_SYNC_SEGUNDOS)
        try:
            conn = db()  # conexión propia de este hilo
            r = procesar_cola_sincronizacion()
            if r["ok"] or r["fallo"]:
                print(f"[sync en segundo plano] ok={r['ok']} fallo={r['fallo']}")
        except Exception as e:
            print("[sync en segundo plano] error:", e)


# ═══════════════════════════════════════════════════════════════
# ACCIONES — misma forma de respuesta que ya usaba api.php/Code.gs
# ═══════════════════════════════════════════════════════════════
def a_getEstado(params, body):
    return {"status": "success", "mantenimiento": get_config("mantenimiento", "false") == "true"}


def a_login(params, body):
    usuario = str(body.get("usuario", "")).lower()
    pw = str(body.get("password", body.get("pin", "")))
    if usuario == "admin" and pw == "admin123":
        log_actividad(body.get("usuario"), "Login", "Sesión iniciada")
        return {"status": "success", "message": "Ingreso exitoso.", "data": {"id": "1", "usuario": "admin", "rol": "admin"}}
    return {"status": "error", "message": "Credenciales de acceso incorrectas."}


def a_getCategorias(params, body):
    rows = db().execute("SELECT * FROM categorias WHERE deleted_at IS NULL").fetchall()
    return {"status": "success", "data": rows_to_list(rows)}


def a_getInventario(params, body):
    rows = db().execute("SELECT * FROM productos WHERE activo=1 AND deleted_at IS NULL").fetchall()
    return {"status": "success", "data": rows_to_list(rows)}


def a_getCompras(params, body):
    rows = db().execute("SELECT * FROM compras ORDER BY fecha DESC").fetchall()
    return {"status": "success", "data": rows_to_list(rows)}


def _ventas_con_detalle(fecha_ini=None, fecha_fin=None):
    q = "SELECT * FROM ventas WHERE 1=1"
    args = []
    if fecha_ini:
        q += " AND fecha >= ?"; args.append(fecha_ini)
    if fecha_fin:
        q += " AND fecha <= ?"; args.append(fecha_fin)
    q += " ORDER BY fecha DESC"
    ventas = rows_to_list(db().execute(q, args).fetchall())
    for v in ventas:
        items = db().execute("SELECT * FROM venta_detalle WHERE venta_id=?", (v["id"],)).fetchall()
        v["items"] = rows_to_list(items)
    return ventas


def a_getVentas(params, body):
    fi = params.get("fecha_inicio", ["1970-01-01"])[0] if "fecha_inicio" in params else None
    ff = params.get("fecha_fin", [None])[0] if "fecha_fin" in params else None
    return {"status": "success", "data": _ventas_con_detalle(fi, ff)}


def a_getReporte(params, body):
    tipo = params.get("tipo", [""])[0]
    fi = (params.get("fecha_inicio", ["1970-01-01"])[0] or "1970-01-01") + (" 00:00:00" if "T" not in (params.get("fecha_inicio", [""])[0] or "") else "")
    ff = (params.get("fecha_fin", [datetime.now().strftime("%Y-%m-%d")])[0] or datetime.now().strftime("%Y-%m-%d")) + (" 23:59:59" if "T" not in (params.get("fecha_fin", [""])[0] or "") else "")
    if tipo == "ventas":
        data = _ventas_con_detalle(fi, ff)
        total = sum(float(v["total"] or 0) for v in data)
        return {"status": "success", "data": data, "resumen": {"total": total, "tickets": len(data)}}
    elif tipo == "compras":
        rows = rows_to_list(db().execute(
            "SELECT * FROM compras WHERE fecha >= ? AND fecha <= ? ORDER BY fecha DESC", (fi, ff)
        ).fetchall())
        total = sum((float(c["precio_compra"] or 0) * int(c["cantidad"] or 0)) for c in rows)
        return {"status": "success", "data": rows, "resumen": {"total": total}}
    return {"status": "error", "message": "Tipo no soportado"}


def a_getPapelera(params, body):
    rows = db().execute("SELECT * FROM papelera ORDER BY fecha_eliminado DESC").fetchall()
    return {"status": "success", "data": rows_to_list(rows)}


def a_getActividad(params, body):
    rows = db().execute("SELECT * FROM actividad ORDER BY fecha DESC LIMIT 500").fetchall()
    return {"status": "success", "data": rows_to_list(rows)}


def a_getSoporte(params, body):
    rows = db().execute("SELECT * FROM soporte ORDER BY fecha DESC").fetchall()
    return {"status": "success", "data": rows_to_list(rows)}


def a_getResponsables(params, body):
    rows = db().execute("SELECT * FROM responsables").fetchall()
    return {"status": "success", "data": rows_to_list(rows)}


def a_getConfigCodigoBarras(params, body):
    return {"status": "success", "activo": get_config("ignorarCerosCodigo", "false") == "true"}


def a_getCodigosDuplicados(params, body):
    productos = rows_to_list(db().execute("SELECT * FROM productos WHERE activo=1 AND deleted_at IS NULL").fetchall())
    ignorar = get_config("ignorarCerosCodigo", "false") == "true"
    grupos = {}
    for p in productos:
        cod = (p.get("codigo") or "").strip()
        if not cod:
            continue
        clave = normalizar_codigo(cod) if ignorar else cod.lower()
        grupos.setdefault(clave, []).append(p)
    dup = [g for g in grupos.values() if len(g) > 1]
    dup.sort(key=lambda g: -len(g))
    return {"status": "success", "data": dup, "total_grupos": len(dup)}


def a_agregarCategoria(params, body):
    id_ = body.get("id") or uid()
    if existe_id("categorias", id_):
        return {"status": "success", "message": "Categoría agregada con éxito."}
    ahora = ahora_iso()
    db().execute(
        "INSERT INTO categorias (id, nombre, emoji, activo, created_at, updated_at) VALUES (?,?,?,1,?,?)",
        (id_, body.get("nombre", ""), body.get("emoji", "📦"), ahora, ahora),
    )
    db().commit()
    encolar("categorias", id_, "agregarCategoria", {**body, "action": "agregarCategoria", "id": id_})
    return {"status": "success", "message": "Categoría agregada con éxito."}


def a_editarCategoria(params, body):
    if not existe_id("categorias", body.get("id")):
        return {"status": "error", "message": "Categoría no encontrada."}
    if body.get("nombre"):
        db().execute("UPDATE categorias SET nombre=?, updated_at=? WHERE id=?", (body["nombre"], ahora_iso(), body["id"]))
        db().commit()
    encolar("categorias", body.get("id"), "editarCategoria", {**body, "action": "editarCategoria"})
    return {"status": "success", "message": "Categoría actualizada con éxito."}


def a_eliminarCategoria(params, body):
    db().execute("DELETE FROM categorias WHERE id=?", (body.get("id"),))
    db().commit()
    encolar("categorias", body.get("id"), "eliminarCategoria", {**body, "action": "eliminarCategoria"})
    return {"status": "success", "message": "Categoría eliminada con éxito."}


def a_agregarProducto(params, body):
    id_ = body.get("id") or uid()
    if existe_id("productos", id_):
        return {"status": "success", "message": "Producto registrado con éxito."}
    codigo = str(body.get("codigo") or "").strip()
    if codigo:
        ignorar = get_config("ignorarCerosCodigo", "false") == "true"
        cod_norm = normalizar_codigo(codigo) if ignorar else codigo.lower()
        activos = db().execute("SELECT nombre, codigo FROM productos WHERE activo=1 AND deleted_at IS NULL").fetchall()
        for p in activos:
            otro = (p["codigo"] or "").strip()
            if not otro:
                continue
            otro_norm = normalizar_codigo(otro) if ignorar else otro.lower()
            if otro_norm == cod_norm:
                return {"status": "error", "message": f'Ese código ya lo tiene registrado "{p["nombre"]}" (código guardado: "{otro}"). Usa un código distinto para que el lector no los confunda.'}
    ahora = ahora_iso()
    db().execute(
        "INSERT INTO productos (id, nombre, codigo, categoria, precio_compra, precio_venta, stock, stock_minimo, "
        "imagen_url, favorito, activo, fecha_creado, updated_at) VALUES (?,?,?,?,?,?,?,?,?,0,1,?,?)",
        (id_, body.get("nombre", ""), codigo, body.get("categoria", ""),
         float(body.get("precio_compra") or 0), float(body.get("precio_venta") or 0),
         int(body.get("stock") or 0), int(body.get("stock_minimo") or 5),
         body.get("imagen_url", ""), ahora, ahora),
    )
    db().commit()
    encolar("productos", id_, "agregarProducto", {**body, "action": "agregarProducto", "id": id_})
    return {"status": "success", "message": "Producto registrado con éxito."}


def a_editarProducto(params, body):
    id_ = body.get("id")
    if not existe_id("productos", id_):
        return {"status": "error", "message": "No encontrado."}
    sets, vals = [], []
    for campo, tipo in [("nombre", str), ("precio_compra", float), ("precio_venta", float),
                         ("stock", int), ("categoria", str), ("codigo", str)]:
        if body.get(campo) not in (None, ""):
            sets.append(f"{campo}=?")
            vals.append(tipo(body[campo]))
    if sets:
        sets.append("updated_at=?"); vals.append(ahora_iso())
        vals.append(id_)
        db().execute(f"UPDATE productos SET {', '.join(sets)} WHERE id=?", vals)
        db().commit()
    encolar("productos", id_, "editarProducto", {**body, "action": "editarProducto"})
    return {"status": "success", "message": "Producto actualizado con éxito."}


def a_eliminarProducto(params, body):
    id_ = body.get("id")
    row = db().execute("SELECT * FROM productos WHERE id=?", (id_,)).fetchone()
    if row:
        datos = json.dumps(row_to_dict(row), ensure_ascii=False)
        pid = uid()
        db().execute(
            "INSERT INTO papelera (id, tipo, datos_originales, fecha_eliminado, eliminado_por) VALUES (?,?,?,?,?)",
            (pid, "Producto", datos, ahora_iso(), body.get("usuario", "Sistema")),
        )
        db().execute("UPDATE productos SET activo=0, updated_at=? WHERE id=?", (ahora_iso(), id_))
        db().commit()
    encolar("productos", id_, "eliminarProducto", {**body, "action": "eliminarProducto"})
    return {"status": "success", "message": "Producto movido a papelera exitosamente."}


def a_restaurarProducto(params, body):
    db().execute("UPDATE productos SET activo=1, updated_at=? WHERE id=?", (ahora_iso(), body.get("id")))
    db().execute("DELETE FROM papelera WHERE id=?", (body.get("papelera_id"),))
    db().commit()
    encolar("productos", body.get("id"), "restaurarProducto", {**body, "action": "restaurarProducto"})
    return {"status": "success", "message": "Producto restaurado con éxito."}


def a_registrarVenta(params, body):
    # ── PASO 1-6 del flujo pedido: crear id, guardar venta+detalle,
    # actualizar stock, encolar, y devolver éxito — TODO esto en SQLite,
    # sin esperar ninguna respuesta de internet/Apps Script. ──
    venta_id = body.get("id") or uid()
    if existe_id("ventas", venta_id):
        # Ya se había guardado (ej. un reintento del propio frontend) — no
        # se vuelve a descontar stock ni a insertar nada de nuevo.
        return {"status": "success", "message": "Venta registrada con éxito.", "data": {"id": venta_id, "ya_existia": True}}

    items = body.get("items", [])
    subtotal = 0.0
    resueltos = []
    for it in items:
        prod = db().execute("SELECT * FROM productos WHERE id=?", (it.get("producto_id"),)).fetchone()
        if not prod:
            return {"status": "error", "message": "Producto no encontrado."}
        if int(prod["stock"] or 0) < int(it.get("cantidad") or 0):
            return {"status": "warning", "message": f'Stock insuficiente de {prod["nombre"]}'}
        sub = float(it.get("precio_unitario") or 0) * int(it.get("cantidad") or 0)
        subtotal += sub
        resueltos.append({"it": it, "nombre": prod["nombre"], "sub": sub})

    total = subtotal
    nombre_cliente = (body.get("cliente_nombre") or "").strip() or "N/A"
    whats_cliente = (body.get("cliente_whatsapp") or "").strip() or "N/A"
    correo_cliente = (body.get("cliente_correo") or "").strip() or "N/A"
    fecha = ahora_iso()

    db().execute(
        "INSERT INTO ventas (id, fecha, cliente_nombre, cliente_whatsapp, cliente_correo, subtotal, descuento, "
        "impuesto, total, pago_con, cambio, usuario, estado) VALUES (?,?,?,?,?,?,0,0,?,?,?,?,'completada')",
        (venta_id, fecha, nombre_cliente, whats_cliente, correo_cliente, subtotal, total,
         float(body.get("pago_con") or 0), float(body.get("cambio") or 0), body.get("usuario", "Sistema")),
    )
    for r in resueltos:
        det_id = uid()
        db().execute(
            "INSERT INTO venta_detalle (id, venta_id, producto_id, producto_nombre, cantidad, precio_unitario, "
            "descuento_linea, subtotal_linea) VALUES (?,?,?,?,?,?,0,?)",
            (det_id, venta_id, r["it"].get("producto_id"), r["nombre"], int(r["it"].get("cantidad") or 0),
             float(r["it"].get("precio_unitario") or 0), r["sub"]),
        )
        db().execute("UPDATE productos SET stock = stock - ?, updated_at=? WHERE id=?",
                      (int(r["it"].get("cantidad") or 0), ahora_iso(), r["it"].get("producto_id")))
    db().commit()
    log_actividad(body.get("usuario"), "Venta", f"Total: ${total}")

    # Encolar para mandar a Apps Script — el ID ya guardado es el MISMO
    # que se manda, así el otro lado nunca genera uno distinto.
    payload_items = [{"producto_id": r["it"].get("producto_id"), "cantidad": int(r["it"].get("cantidad") or 0),
                       "precio_unitario": float(r["it"].get("precio_unitario") or 0)} for r in resueltos]
    encolar("ventas", venta_id, "registrarVenta", {
        "action": "registrarVenta", "id": venta_id, "items": payload_items,
        "cliente_nombre": nombre_cliente, "cliente_whatsapp": whats_cliente, "cliente_correo": correo_cliente,
        "pago_con": body.get("pago_con", 0), "cambio": body.get("cambio", 0), "usuario": body.get("usuario", "Sistema"),
    })

    return {
        "status": "success", "message": "Venta registrada con éxito.",
        "data": {
            "id": venta_id, "fecha": fecha, "cliente_nombre": nombre_cliente,
            "cliente_whatsapp": whats_cliente, "cliente_correo": correo_cliente,
            "subtotal": subtotal, "total": total, "pago_con": body.get("pago_con", 0), "cambio": body.get("cambio", 0),
            "items": [{"producto_nombre": r["nombre"], "cantidad": int(r["it"].get("cantidad") or 0),
                       "precio_unitario": float(r["it"].get("precio_unitario") or 0), "subtotal_linea": r["sub"]} for r in resueltos],
        },
    }


def a_registrarCompra(params, body):
    id_ = body.get("id") or uid()
    if existe_id("compras", id_):
        return {"status": "success", "message": "Compra registrada con éxito. Inventario actualizado."}
    cantidad = int(body.get("cantidad") or 0)
    precio_compra = float(body.get("precio_compra") or 0)
    db().execute(
        "INSERT INTO compras (id, producto_id, cantidad, precio_compra, fecha, usuario, notas) VALUES (?,?,?,?,?,?,?)",
        (id_, body.get("producto_id"), cantidad, precio_compra, ahora_iso(), body.get("usuario", "Sistema"), body.get("notas", "")),
    )
    sets, vals = ["stock = stock + ?", "precio_compra=?", "updated_at=?"], [cantidad, precio_compra, ahora_iso()]
    if body.get("precio_venta") not in (None, ""):
        sets.append("precio_venta=?"); vals.append(float(body["precio_venta"]))
    prov = (body.get("proveedor_nombre") or "").strip()
    sets += ["proveedor_nombre=?", "proveedor_whatsapp=?", "proveedor_correo=?"]
    vals += [prov, (body.get("proveedor_whatsapp") or "").strip(), (body.get("proveedor_correo") or "").strip()]
    if prov:
        sets.append("proveedor_fecha_entrada=?"); vals.append(ahora_iso())
    vals.append(body.get("producto_id"))
    db().execute(f"UPDATE productos SET {', '.join(sets)} WHERE id=?", vals)
    db().commit()
    encolar("compras", id_, "registrarCompra", {**body, "action": "registrarCompra", "id": id_})
    return {"status": "success", "message": "Compra registrada con éxito. Inventario actualizado."}


def a_crearTicketSoporte(params, body):
    id_ = body.get("id") or uid()
    if existe_id("soporte", id_):
        return {"status": "success", "message": "Ticket de soporte creado."}
    ahora = ahora_iso()
    db().execute(
        "INSERT INTO soporte (id, usuario, titulo, descripcion, estado, fecha, fecha_actualizado) "
        "VALUES (?,?,?,?, 'nuevo', ?, ?)",
        (id_, body.get("usuario", ""), body.get("titulo", ""), body.get("descripcion", ""), ahora, ahora),
    )
    db().commit()
    encolar("soporte", id_, "crearTicketSoporte", {**body, "action": "crearTicketSoporte", "id": id_})
    return {"status": "success", "message": "Ticket de soporte creado."}


def a_agregarResponsable(params, body):
    id_ = body.get("id") or uid()
    if existe_id("responsables", id_):
        return {"status": "success", "message": "Responsable agregado con éxito."}
    db().execute(
        "INSERT INTO responsables (id, email, nombre, reportes, umbral_venta_grande, activo, fecha_creado) "
        "VALUES (?,?,?,?,?,1,?)",
        (id_, body.get("email", ""), body.get("nombre", ""), body.get("reportes", ""),
         float(body.get("umbral_venta_grande") or 100), ahora_iso()),
    )
    db().commit()
    encolar("responsables", id_, "agregarResponsable", {**body, "action": "agregarResponsable", "id": id_})
    return {"status": "success", "message": "Responsable agregado con éxito."}


def a_editarResponsable(params, body):
    id_ = body.get("id")
    if not existe_id("responsables", id_):
        return {"status": "error", "message": "Responsable no encontrado."}
    db().execute(
        "UPDATE responsables SET email=?, nombre=?, reportes=?, umbral_venta_grande=?, activo=? WHERE id=?",
        (body.get("email", ""), body.get("nombre", ""), body.get("reportes", ""),
         float(body.get("umbral_venta_grande") or 100), 1 if body.get("activo") else 0, id_),
    )
    db().commit()
    encolar("responsables", id_, "editarResponsable", {**body, "action": "editarResponsable"})
    return {"status": "success", "message": "Responsable actualizado con éxito."}


def a_eliminarResponsable(params, body):
    db().execute("DELETE FROM responsables WHERE id=?", (body.get("id"),))
    db().commit()
    encolar("responsables", body.get("id"), "eliminarResponsable", {**body, "action": "eliminarResponsable"})
    return {"status": "success", "message": "Responsable eliminado con éxito."}


def a_setConfigCodigoBarras(params, body):
    set_config("ignorarCerosCodigo", "true" if body.get("activo") else "false")
    log_actividad(body.get("usuario", "admin"), "Configuración",
                  f'Búsqueda de código de barras ignorando ceros: {"ACTIVADA" if body.get("activo") else "DESACTIVADA"}')
    encolar("config", "ignorarCerosCodigo", "setConfigCodigoBarras", {**body, "action": "setConfigCodigoBarras"})
    return {"status": "success", "message": "Configuración actualizada con éxito.", "activo": bool(body.get("activo"))}


def a_activarMantenimiento(params, body):
    set_config("mantenimiento", "true")
    return {"status": "success", "message": "Mantenimiento activado."}


def a_desactivarMantenimiento(params, body):
    set_config("mantenimiento", "false")
    return {"status": "success", "message": "Mantenimiento desactivado."}


def a_iniciar(params, body):
    inicializar_bd()
    return {"status": "success", "message": "Base de datos local (SQLite) inicializada correctamente. No se borró nada existente."}


def a_resetear(params, body):
    for t in ["venta_detalle", "ventas", "compras", "papelera", "actividad", "soporte", "responsables", "productos", "categorias", "sync_queue"]:
        db().execute(f"DELETE FROM {t}")
    db().commit()
    return {"status": "success", "message": "¡Formateo completado! Base de datos local recreada desde cero."}


def a_getEstadoSincronizacion(params, body):
    pend = db().execute("SELECT COUNT(*) c FROM sync_queue WHERE estado IN ('PENDIENTE','ERROR')").fetchone()["c"]
    sinc = db().execute("SELECT COUNT(*) c FROM sync_queue WHERE estado='SINCRONIZADO'").fetchone()["c"]
    return {"status": "success", "pendientes": pend, "sincronizados": sinc}


def a_sincronizar(params, body):
    """Acción llamable a pedido (además del hilo de fondo): procesa la
    cola local→nube Y trae lo nuevo nube→local, en un solo paso."""
    subida = procesar_cola_sincronizacion()
    bajada = _sincronizar_desde_appscript()
    return {"status": "success", "subida": subida, "bajada": bajada}


# ── MIGRACIÓN / DESCARGA DESDE APPS SCRIPT ──
def _pedir_appscript(action, extra_params=None, timeout=90):
    qs = "?action=" + action
    if extra_params:
        for k, v in extra_params.items():
            qs += f"&{k}={urllib.request.quote(str(v))}"
    try:
        with urllib.request.urlopen(APPSCRIPT_URL + qs, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        print("[appscript] error pidiendo", action, ":", e)
        return None


def a_migrarDesdeAppScript(params, body):
    """Trae TODO desde Google Sheets y reemplaza el contenido local
    (borra e inserta de nuevo) — para la primera instalación o para
    forzar una copia 1:1 completa."""
    # Esta función se salta el candado general (para no bloquear el resto
    # del sistema durante las llamadas lentas a Apps Script, ver más
    # abajo), así que TODO lo que toque SQLite aquí adentro necesita su
    # propio "with DB_LOCK:" explícito — incluida esta línea, que antes se
    # quedaba desprotegida y podía chocar justo con la sincronización
    # automática que corre sola al abrir la página.
    with DB_LOCK:
        inicializar_bd()
    resumen = {}

    cats = _pedir_appscript("getCategorias")
    prods = _pedir_appscript("getInventario")
    hoy = datetime.now().strftime("%Y-%m-%d")
    ventas = _pedir_appscript("getVentas")
    compras = _pedir_appscript("getReporte", {"tipo": "compras", "fecha_inicio": "2000-01-01", "fecha_fin": hoy})
    papelera = _pedir_appscript("getPapelera")
    actividad = _pedir_appscript("getActividad")
    soporte = _pedir_appscript("getSoporte")
    responsables = _pedir_appscript("getResponsables")

    with DB_LOCK:
        conn = db()
        for t in ["venta_detalle", "ventas", "compras", "papelera", "actividad", "soporte", "responsables", "productos", "categorias"]:
            conn.execute(f"DELETE FROM {t}")

        # A partir de aquí se usa executemany() (inserta todas las filas de
        # una vez) en lugar de un execute() por fila. Con miles de filas
        # (ventas, actividad) y Apps Script respondiendo lento, insertar
        # una por una podía dejar la transacción abierta por minutos —
        # tiempo de sobra para que alguien cierre la ventana a mitad de
        # camino y se pierda todo el trabajo. executemany() hace lo mismo
        # en una fracción del tiempo.
        if cats and cats.get("status") == "success":
            filas = [(c.get("id"), c.get("nombre", ""), c.get("emoji", "📦"),
                      1 if c.get("activo") in (True, "true", 1) else 1, ahora_iso(), ahora_iso())
                     for c in cats["data"]]
            conn.executemany("INSERT OR IGNORE INTO categorias (id, nombre, emoji, activo, created_at, updated_at) VALUES (?,?,?,?,?,?)", filas)
            resumen["categorias"] = len(filas)

        if prods and prods.get("status") == "success":
            filas = [(p.get("id"), p.get("nombre", ""), p.get("código", p.get("codigo", "")), p.get("categoría", p.get("categoria", "")),
                      float(p.get("precio_compra") or 0), float(p.get("precio_venta") or 0), int(p.get("stock") or 0),
                      int(p.get("stock_minimo") or 5), p.get("imagen_url", ""), ahora_iso(),
                      p.get("proveedor_nombre", ""), p.get("proveedor_whatsapp", ""), p.get("proveedor_correo", ""))
                     for p in prods["data"]]
            conn.executemany(
                "INSERT OR IGNORE INTO productos (id, nombre, codigo, categoria, precio_compra, precio_venta, stock, "
                "stock_minimo, imagen_url, favorito, activo, fecha_creado, proveedor_nombre, proveedor_whatsapp, proveedor_correo) "
                "VALUES (?,?,?,?,?,?,?,?,?,0,1,?,?,?,?)", filas)
            resumen["productos"] = len(filas)

        if compras and compras.get("status") == "success":
            filas = [(c.get("id"), c.get("producto_id"), int(c.get("cantidad") or 0), float(c.get("precio_compra") or 0),
                      c.get("fecha"), c.get("usuario", "Sistema"), c.get("notas", ""))
                     for c in compras["data"]]
            conn.executemany("INSERT OR IGNORE INTO compras (id, producto_id, cantidad, precio_compra, fecha, usuario, notas) VALUES (?,?,?,?,?,?,?)", filas)
            resumen["compras"] = len(filas)

        if ventas and ventas.get("status") == "success":
            filas_v = [(v.get("id"), v.get("fecha"), v.get("cliente_nombre", "N/A"), v.get("cliente_whatsapp", "N/A"),
                        v.get("cliente_correo", "N/A"), float(v.get("subtotal") or v.get("total") or 0), float(v.get("total") or 0),
                        float(v.get("pago_con") or 0), float(v.get("cambio") or 0), v.get("usuario", "Sistema"), v.get("estado", "completada"))
                       for v in ventas["data"]]
            conn.executemany(
                "INSERT OR IGNORE INTO ventas (id, fecha, cliente_nombre, cliente_whatsapp, cliente_correo, subtotal, "
                "descuento, impuesto, total, pago_con, cambio, usuario, estado) VALUES (?,?,?,?,?,?,0,0,?,?,?,?,?)", filas_v)
            filas_d = [(it.get("id") or uid(), v.get("id"), it.get("producto_id"), it.get("producto_nombre", ""),
                        int(it.get("cantidad") or 0), float(it.get("precio_unitario") or 0), float(it.get("subtotal_linea") or 0))
                       for v in ventas["data"] for it in v.get("items", [])]
            conn.executemany(
                "INSERT OR IGNORE INTO venta_detalle (id, venta_id, producto_id, producto_nombre, cantidad, "
                "precio_unitario, descuento_linea, subtotal_linea) VALUES (?,?,?,?,?,?,0,?)", filas_d)
            resumen["ventas"] = len(filas_v)
            resumen["venta_detalle"] = len(filas_d)

        if papelera and papelera.get("status") == "success":
            filas = [(p.get("id"), p.get("tipo", "Producto"), p.get("datos_originales", ""), p.get("fecha_eliminado"), p.get("eliminado_por", "Sistema"))
                     for p in papelera["data"]]
            conn.executemany("INSERT OR IGNORE INTO papelera (id, tipo, datos_originales, fecha_eliminado, eliminado_por) VALUES (?,?,?,?,?)", filas)
            resumen["papelera"] = len(filas)

        if actividad and actividad.get("status") == "success":
            filas = [(a.get("id"), a.get("fecha"), a.get("usuario", "Sistema"), a.get("accion", ""), a.get("detalle", ""))
                     for a in actividad["data"]]
            conn.executemany("INSERT OR IGNORE INTO actividad (id, fecha, usuario, accion, detalle) VALUES (?,?,?,?,?)", filas)
            resumen["actividad"] = len(filas)

        if soporte and soporte.get("status") == "success":
            filas = [(s.get("id"), s.get("usuario", ""), s.get("titulo", ""), s.get("descripcion", ""), s.get("estado", "nuevo"),
                      s.get("fecha"), s.get("fecha_actualizado"), s.get("respuesta", ""), s.get("admin", ""))
                     for s in soporte["data"]]
            conn.executemany("INSERT OR IGNORE INTO soporte (id, usuario, titulo, descripcion, estado, fecha, fecha_actualizado, respuesta, admin) VALUES (?,?,?,?,?,?,?,?,?)", filas)
            resumen["soporte"] = len(filas)

        if responsables and responsables.get("status") == "success":
            filas = [(r.get("id"), r.get("email", ""), r.get("nombre", ""), r.get("reportes", ""),
                      float(r.get("umbral_venta_grande") or 100), 1 if r.get("activo") in (True, "true", 1) else 0, ahora_iso())
                     for r in responsables["data"]]
            conn.executemany("INSERT OR IGNORE INTO responsables (id, email, nombre, reportes, umbral_venta_grande, activo, fecha_creado) VALUES (?,?,?,?,?,?,?)", filas)
            resumen["responsables"] = len(filas)

        conn.commit()
        set_config("ultima_migracion_total", ahora_iso())
    return {"status": "success", "message": "Migración completada.", "resumen": resumen}


def _sincronizar_desde_appscript():
    """Incremental — solo trae lo que falte, sin borrar nada (a diferencia
    de migrarDesdeAppScript). Se llama sola en segundo plano.

    IMPORTANTE (bug ya corregido): antes esta función alternaba llamadas
    de red a Apps Script (que pueden tardar varios segundos cada una) con
    escrituras en SQLite, dejando la base "abierta para escribir" durante
    todo ese tiempo. Si en ese momento otro hilo intentaba guardar algo
    (por ejemplo una venta, o el sincronizador de fondo), se topaba con
    "database is locked". Ahora primero se piden TODOS los datos a Apps
    Script (sin tocar la base todavía) y solo al final, con todo ya en
    memoria, se abre la base y se escribe rápido — sin ninguna llamada de
    red de por medio mientras el candado de escritura está tomado."""
    resumen = {}
    desde60 = (datetime.now() - timedelta(days=60)).strftime("%Y-%m-%d")
    hoy = datetime.now().strftime("%Y-%m-%d")

    # ── FASE 1: solo lectura por red (nada de SQLite todavía) ──
    cats = _pedir_appscript("getCategorias")
    prods = _pedir_appscript("getInventario")
    ventas = _pedir_appscript("getReporte", {"tipo": "ventas", "fecha_inicio": desde60, "fecha_fin": hoy})
    compras = _pedir_appscript("getReporte", {"tipo": "compras", "fecha_inicio": desde60, "fecha_fin": hoy})
    resp = _pedir_appscript("getResponsables")

    # ── FASE 2: todo en SQLite, rápido, sin esperar a la red en ningún punto ──
    with DB_LOCK:
        conn = db()

        if cats and cats.get("status") == "success":
            existentes = {r["id"] for r in conn.execute("SELECT id FROM categorias").fetchall()}
            n = 0
            for c in cats["data"]:
                if not c.get("id") or c["id"] in existentes:
                    continue
                conn.execute("INSERT OR IGNORE INTO categorias (id, nombre, emoji, activo, created_at, updated_at) VALUES (?,?,?,1,?,?)",
                             (c["id"], c.get("nombre", ""), c.get("emoji", "📦"), ahora_iso(), ahora_iso()))
                n += 1
            resumen["categorias_nuevas"] = n

        if prods and prods.get("status") == "success":
            existentes = {r["id"] for r in conn.execute("SELECT id FROM productos").fetchall()}
            n = 0
            for p in prods["data"]:
                pid = p.get("id")
                if not pid or pid in existentes:
                    continue
                conn.execute(
                    "INSERT OR IGNORE INTO productos (id, nombre, codigo, categoria, precio_compra, precio_venta, stock, stock_minimo, "
                    "imagen_url, favorito, activo, fecha_creado) VALUES (?,?,?,?,?,?,?,?,?,0,1,?)",
                    (pid, p.get("nombre", ""), p.get("código", p.get("codigo", "")), p.get("categoría", p.get("categoria", "")),
                     float(p.get("precio_compra") or 0), float(p.get("precio_venta") or 0), int(p.get("stock") or 0),
                     int(p.get("stock_minimo") or 5), p.get("imagen_url", ""), ahora_iso()),
                )
                n += 1
            resumen["productos_nuevos"] = n

        if ventas and ventas.get("status") == "success":
            existentes = {r["id"] for r in conn.execute("SELECT id FROM ventas WHERE fecha >= ?", (desde60,)).fetchall()}
            n = 0
            for v in ventas["data"]:
                vid = v.get("id")
                if not vid or vid in existentes:
                    continue
                conn.execute(
                    "INSERT OR IGNORE INTO ventas (id, fecha, cliente_nombre, cliente_whatsapp, cliente_correo, subtotal, descuento, "
                    "impuesto, total, pago_con, cambio, usuario, estado) VALUES (?,?,?,?,?,?,0,0,?,?,?,?,?)",
                    (vid, v.get("fecha"), v.get("cliente_nombre", "N/A"), v.get("cliente_whatsapp", "N/A"), v.get("cliente_correo", "N/A"),
                     float(v.get("subtotal") or v.get("total") or 0), float(v.get("total") or 0),
                     float(v.get("pago_con") or 0), float(v.get("cambio") or 0), v.get("usuario", "Sistema"), v.get("estado", "completada")),
                )
                for it in v.get("items", []):
                    conn.execute(
                        "INSERT OR IGNORE INTO venta_detalle (id, venta_id, producto_id, producto_nombre, cantidad, precio_unitario, descuento_linea, subtotal_linea) "
                        "VALUES (?,?,?,?,?,?,0,?)",
                        (it.get("id") or uid(), vid, it.get("producto_id"), it.get("producto_nombre", ""),
                         int(it.get("cantidad") or 0), float(it.get("precio_unitario") or 0), float(it.get("subtotal_linea") or 0)),
                    )
                n += 1
            resumen["ventas_nuevas"] = n

        if compras and compras.get("status") == "success":
            existentes = {r["id"] for r in conn.execute("SELECT id FROM compras WHERE fecha >= ?", (desde60,)).fetchall()}
            n = 0
            for c in compras["data"]:
                cid = c.get("id")
                if not cid or cid in existentes:
                    continue
                conn.execute("INSERT OR IGNORE INTO compras (id, producto_id, cantidad, precio_compra, fecha, usuario, notas) VALUES (?,?,?,?,?,?,?)",
                             (cid, c.get("producto_id"), int(c.get("cantidad") or 0), float(c.get("precio_compra") or 0),
                              c.get("fecha"), c.get("usuario", "Sistema"), c.get("notas", "")))
                n += 1
            resumen["compras_nuevas"] = n

        if resp and resp.get("status") == "success":
            existentes = {r["id"] for r in conn.execute("SELECT id FROM responsables").fetchall()}
            n = 0
            for r in resp["data"]:
                rid = r.get("id")
                if not rid or rid in existentes:
                    continue
                conn.execute("INSERT OR IGNORE INTO responsables (id, email, nombre, reportes, umbral_venta_grande, activo, fecha_creado) VALUES (?,?,?,?,?,?,?)",
                             (rid, r.get("email", ""), r.get("nombre", ""), r.get("reportes", ""),
                              float(r.get("umbral_venta_grande") or 100), 1 if r.get("activo") in (True, "true", 1) else 0, ahora_iso()))
                n += 1
            resumen["responsables_nuevos"] = n

        conn.commit()
        return resumen


ACCIONES_LOCALES = {
    "getEstado": a_getEstado, "login": a_login, "getCategorias": a_getCategorias,
    "getInventario": a_getInventario, "getCompras": a_getCompras, "getVentas": a_getVentas,
    "getReporte": a_getReporte, "getPapelera": a_getPapelera, "getActividad": a_getActividad,
    "getSoporte": a_getSoporte, "getResponsables": a_getResponsables,
    "getConfigCodigoBarras": a_getConfigCodigoBarras, "getCodigosDuplicados": a_getCodigosDuplicados,
    "agregarCategoria": a_agregarCategoria, "editarCategoria": a_editarCategoria, "eliminarCategoria": a_eliminarCategoria,
    "agregarProducto": a_agregarProducto, "editarProducto": a_editarProducto, "eliminarProducto": a_eliminarProducto,
    "restaurarProducto": a_restaurarProducto, "registrarVenta": a_registrarVenta, "registrarCompra": a_registrarCompra,
    "crearTicketSoporte": a_crearTicketSoporte, "agregarResponsable": a_agregarResponsable,
    "editarResponsable": a_editarResponsable, "eliminarResponsable": a_eliminarResponsable,
    "setConfigCodigoBarras": a_setConfigCodigoBarras, "activarMantenimiento": a_activarMantenimiento,
    "desactivarMantenimiento": a_desactivarMantenimiento, "iniciar": a_iniciar, "resetear": a_resetear,
    "migrarDesdeAppScript": a_migrarDesdeAppScript, "getEstadoSincronizacion": a_getEstadoSincronizacion,
    "sincronizar": a_sincronizar,
}
ACCIONES_SISTEMA = {"getEstado", "activarMantenimiento", "desactivarMantenimiento", "iniciar", "resetear", "login"}


def manejar_accion(action, params, body):
    if action not in ACCIONES_LOCALES:
        # No la manejamos localmente: se reenvía tal cual a Apps Script
        # (Hacienda, envío de correos/reportes, etc.) — igual que hacía
        # api.php, así nada de eso deja de funcionar. Esto no toca SQLite
        # para nada, así que no necesita el candado.
        payload = dict(body or {})
        payload["action"] = action
        for k, v in (params or {}).items():
            payload.setdefault(k, v[0] if isinstance(v, list) else v)
        data = _pedir_appscript(action) if not body else None
        if data is None:
            ok, data, err = llamar_appscript(payload)
            if data is None:
                return {"status": "error", "message": f"No se pudo contactar Apps Script para '{action}': {err}"}
        return data

    # "sincronizar" y "migrarDesdeAppScript" hablan con internet como parte
    # de su trabajo normal (pueden tardar varios segundos) — SI se
    # quedaran con el candado general durante todo ese tiempo, bloquearían
    # el resto del sistema (ventas, inventario) mientras tanto. Por eso
    # manejan su propio candado por dentro, solo durante los instantes
    # rápidos de lectura/escritura en SQLite, nunca durante la llamada a
    # Apps Script.
    ACCIONES_CON_RED_LARGA = {"sincronizar", "migrarDesdeAppScript"}
    if action in ACCIONES_CON_RED_LARGA:
        try:
            return ACCIONES_LOCALES[action](params, body)
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # A partir de aquí SÍ se toca SQLite — todo bajo el candado global, para
    # que nunca haya dos hilos escribiendo/leyendo al mismo tiempo. Se
    # mantiene además un reintento por si alguna vez algo externo al propio
    # programa (otro proceso, un antivirus) llega a tocar el archivo.
    intentos = 5
    espera = 0.3
    for intento in range(intentos):
        try:
            with DB_LOCK:
                if action not in ACCIONES_SISTEMA and get_config("mantenimiento", "false") == "true":
                    return {"status": "mantenimiento", "message": "Sistema en mantenimiento. Intente más tarde."}
                return ACCIONES_LOCALES[action](params, body)
        except sqlite3.OperationalError as e:
            if "locked" in str(e).lower() and intento < intentos - 1:
                try:
                    db().rollback()
                except Exception:
                    pass
                time.sleep(espera)
                espera *= 1.8
                continue
            return {"status": "error", "message": f"La base de datos local está ocupada (¿tienes otra ventana de iniciar.bat abierta, o algún antivirus revisando la carpeta?): {e}"}
        except Exception as e:
            return {"status": "error", "message": str(e)}


# ═══════════════════════════════════════════════════════════════
# SERVIDOR HTTP
# ═══════════════════════════════════════════════════════════════
MIME = {".html": "text/html; charset=utf-8", ".js": "application/javascript", ".css": "text/css",
        ".json": "application/json", ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml",
        ".ico": "image/x-icon", ".md": "text/markdown; charset=utf-8"}


class Handler(BaseHTTPRequestHandler):
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def _responder_json(self, data):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self._cors()
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        from urllib.parse import urlparse, parse_qs
        parsed = urlparse(self.path)
        if parsed.path == "/api":
            qs = parse_qs(parsed.query)
            action = qs.get("action", [""])[0]
            self._responder_json(manejar_accion(action, qs, {}))
            return
        # Servir archivos estáticos (index.html, registro-masivo.html, etc.)
        ruta = parsed.path
        if ruta == "/":
            ruta = "/index.html"
        archivo = (FRONTEND_DIR / ruta.lstrip("/")).resolve()
        try:
            archivo.relative_to(FRONTEND_DIR.resolve())
        except ValueError:
            self.send_response(403); self.end_headers(); return
        if archivo.is_file():
            self.send_response(200)
            self.send_header("Content-Type", MIME.get(archivo.suffix, "application/octet-stream"))
            # Sin esto, el navegador puede quedarse con una versión vieja de
            # index.html en caché y no darse cuenta de que hay una nueva en
            # el disco, aunque reemplaces el archivo.
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
            self._cors()
            self.end_headers()
            self.wfile.write(archivo.read_bytes())
        else:
            self.send_response(404)
            self._cors()
            self.end_headers()
            self.wfile.write(b"No encontrado")

    def do_POST(self):
        from urllib.parse import urlparse
        parsed = urlparse(self.path)
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b"{}"
        try:
            body = json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            body = {}
        if parsed.path == "/api":
            action = body.get("action", "")
            self._responder_json(manejar_accion(action, {}, body))
        else:
            self.send_response(404); self._cors(); self.end_headers()

    def log_message(self, fmt, *args):
        pass  # silencioso — no llena la terminal con cada pedido


def main():
    # Si ya hay un servidor corriendo en este puerto (por ejemplo, otra
    # ventana de iniciar.bat que quedó abierta de antes), avisar claro en
    # vez de arrancar un SEGUNDO proceso encima — dos procesos de Python
    # escribiendo al mismo tiempo en el mismo archivo .db es justo lo que
    # provoca los bloqueos "database is locked" más tercos.
    import socket
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ya_hay_uno = probe.connect_ex(("127.0.0.1", PUERTO)) == 0
    probe.close()
    if ya_hay_uno:
        print(f"[erp-pos-lite] Ya hay un servidor corriendo en el puerto {PUERTO}.")
        print("[erp-pos-lite] No se abre un segundo servidor — usa la ventana que ya estaba abierta,")
        print(f"[erp-pos-lite] o ciérrala primero si quieres reiniciar. Abriendo el navegador ahí:")
        try:
            webbrowser.open(f"http://localhost:{PUERTO}/index.html")
        except Exception:
            pass
        input("Presiona Enter para cerrar esta ventana...")
        return

    inicializar_bd()
    hilo = threading.Thread(target=hilo_sincronizacion_fondo, daemon=True)
    hilo.start()
    server = ThreadingHTTPServer(("0.0.0.0", PUERTO), Handler)
    print(f"[erp-pos-lite] Servidor local corriendo en http://localhost:{PUERTO}")
    print(f"[erp-pos-lite] Base de datos: {DB_PATH}")
    print("[erp-pos-lite] Presiona Ctrl+C para detener.")
    try:
        webbrowser.open(f"http://localhost:{PUERTO}/index.html")
    except Exception:
        pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[erp-pos-lite] Detenido.")


if __name__ == "__main__":
    main()
