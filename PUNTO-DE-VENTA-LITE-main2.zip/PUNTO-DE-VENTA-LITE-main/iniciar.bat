@echo off
REM ═══════════════════════════════════════════════════════════
REM ERP POS LITE — Iniciar sistema local (Python + SQLite)
REM No necesita XAMPP, MySQL ni phpMyAdmin.
REM ═══════════════════════════════════════════════════════════
title ERP POS LITE - Servidor Local
cd /d "%~dp0backend"

echo ============================================
echo   ERP POS LITE - Iniciando servidor local
echo ============================================
echo.

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] No se encontro Python instalado.
    echo Descargalo desde https://www.python.org/downloads/
    echo IMPORTANTE: al instalar, marca la casilla "Add python.exe to PATH".
    pause
    exit /b 1
)

echo Iniciando API local en http://localhost:8000 ...
echo (Esta ventana debe quedar abierta mientras uses el sistema.)
echo Para cerrar el sistema, cierra esta ventana o presiona Ctrl+C.
echo.

python server.py

pause
